# ISTIO GCP

This is the top-level kustomization.yaml file for installing ISTIO 1.1.6
on GCP.

This packacge only installs ISTIO; not Kubeflwo specific resources (E.g gateways for Kubeflow)

This will be replaced soon with managed ISTIO.